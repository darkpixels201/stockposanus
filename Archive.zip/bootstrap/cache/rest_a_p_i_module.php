<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\RestAPI\\Providers\\RestAPIServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\RestAPI\\Providers\\RestAPIServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);